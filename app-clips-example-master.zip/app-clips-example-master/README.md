<img src="https://github.com/exyte/app-clips-example/blob/master/Assets/header.png">

# App Clips Example App

With the iOS 14 release Apple added a new way to experience your app's features called App Clips.

<a href="https://exyte.com/blog/introduction-to-app-clips?utm_source=github&utm_medium=referral&utm_campaign=website_blog">Read Article »</a>


# Credits

- [Transport 3 Icon Set](https://www.iconfinder.com/icons/3362526/scooter_bike_push_scooter_kick_icon) by Josy Dom Alexis
- [WHCompare Servers & Web Hosting Icon Set](https://www.iconfinder.com/icons/4263521/chat_24/7_operator_support_live_icon) by Alexiuz AS
