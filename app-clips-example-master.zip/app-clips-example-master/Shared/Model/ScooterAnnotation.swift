import Foundation
import MapKit

class ScooterAnnotation: MKPointAnnotation {
    
    var scooter: Scooter?
    
}
